from selenium.webdriver.common.by import By

from pageObjects.CheckoutPage import CheckOutPage


class LogInPage:

    def __init__(self, driver):
        self.driver = driver


    email = (By.XPATH, "//*[@id='root']/div/main/div/div/div[1]/div[2]/div/div/div[1]/div/input")
    password = (By.XPATH, "//*[@id='root']/div/main/div/div/div[1]/div[2]/div/div/div[2]/div/input")
    login = (By.XPATH, "//*[@id='root']/div/main/div/div/div[1]/div[2]/div/div/button")
    successMessage = (By.CSS_SELECTOR, "[class*='alert-success']")

    def shopItems(self):
        self.driver.find_element(*login.shop).click()
        checkOutPage = CheckOutPage(self.driver)
        return checkOutPage

    def getName(self):
        return self.driver.find_element(*login.name)


    def getEmail(self):
        return self.driver.find_element(*HomePage.email)

    def getCheckBox(self):
        return self.driver.find_element(*HomePage.check)

    def getGender(self):
        return self.driver.find_element(*HomePage.gender)

    def submitForm(self):
        return self.driver.find_element(*HomePage.submit)

    def getSuccessMessage(self):
        return self.driver.find_element(*HomePage.successMessage)




